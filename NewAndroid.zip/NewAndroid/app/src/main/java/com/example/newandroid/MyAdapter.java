package com.example.newandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;
    ArrayList<Verbs> list;

    public MyAdapter(Context context, ArrayList<Verbs> list) {
        this.context = context;
        this.list = list;
    }



    public MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
            return new MyViewHolder(v);
    }
    @NonNull
    @Override
    public void onBindViewHolder(@NonNull MyAdapter.MyViewHolder holder, int position) {
            Verbs verbs = list.get(position);
            holder.word.setText(verbs.getWord());
            holder.meaning.setText(verbs.getMeaning());
            holder.example.setText(verbs.getExample());
            holder.snonym.setText(verbs.getSnonym());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView word, meaning, example, snonym;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);

            word = itemView.findViewById(R.id.txtWord);
            meaning = itemView.findViewById(R.id.txtMeaning);
            example = itemView.findViewById(R.id.txtExample);
            snonym = itemView.findViewById(R.id.txtSnonym);

        }
    }
}
