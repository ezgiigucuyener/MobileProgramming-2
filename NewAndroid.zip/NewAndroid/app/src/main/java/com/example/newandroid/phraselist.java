package com.example.newandroid;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
public class phraselist extends AppCompatActivity{

    RecyclerView recyclerViewom;
    DatabaseReference databaseom;
    MyAdapterom myAdapterom;
    ArrayList<Phrases> listom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phraselist);

        recyclerViewom = findViewById(R.id.phraseList);
        databaseom = FirebaseDatabase.getInstance().getReference("Phrases");
        recyclerViewom.setHasFixedSize(true);
        recyclerViewom.setLayoutManager(new LinearLayoutManager(this));

        listom = new ArrayList<>();

        myAdapterom = new MyAdapterom(this,listom);
        recyclerViewom.setAdapter(myAdapterom);

        databaseom.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Phrases phrases = dataSnapshot.getValue(Phrases.class);
                    listom.add(phrases);
                }

                myAdapterom.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        })


        ;}
}
