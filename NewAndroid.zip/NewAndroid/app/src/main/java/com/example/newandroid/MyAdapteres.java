package com.example.newandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

    public class MyAdapteres extends RecyclerView.Adapter<MyAdapteres.MyViewHolderes> {

        Context contextes;
        ArrayList<Adjectives> listes;

        public MyAdapteres(Context contextes, ArrayList<Adjectives> listes) {
            this.contextes = contextes;
            this.listes = listes;
        }

        @NonNull
        public MyViewHolderes onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View ve = LayoutInflater.from(contextes).inflate(R.layout.itemes,parent,false);
            return new MyViewHolderes(ve);
        }

        public void onBindViewHolder(@NonNull MyViewHolderes holderes, int position) {
            Adjectives adjectives = listes.get(position);
            holderes.wordes.setText(adjectives.getWordes());
            holderes.meaninges.setText(adjectives.getMeaninges());
            holderes.examplees.setText(adjectives.getExamplees());
            holderes.snonymes.setText(adjectives.getSnonymes());


        }

        @Override
        public int getItemCount() {
            return listes.size();
        }

        public static class MyViewHolderes extends RecyclerView.ViewHolder{

            TextView wordes, meaninges, examplees, snonymes;

            public MyViewHolderes(@NonNull View itemView){
                super(itemView);

                wordes = itemView.findViewById(R.id.txtWordes);
                meaninges = itemView.findViewById(R.id.txtMeaninges);
                examplees = itemView.findViewById(R.id.txtExamplees);
                snonymes = itemView.findViewById(R.id.txtSnonymes);

            }
        }
    }


