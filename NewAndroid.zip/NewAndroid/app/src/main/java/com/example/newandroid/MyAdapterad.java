package com.example.newandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class MyAdapterad extends RecyclerView.Adapter<MyAdapterad.MyViewHolderad> {

    Context contextad;
    ArrayList<Adverbs> listad;

    public MyAdapterad(Context contextad, ArrayList<Adverbs> listad) {
        this.contextad = contextad;
        this.listad = listad;
    }



    @NonNull
    public MyViewHolderad onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View vi = LayoutInflater.from(contextad).inflate(R.layout.itemad,parent,false);
        return new MyViewHolderad(vi);
    }

    public void onBindViewHolder(@NonNull MyViewHolderad holderad, int position) {
        Adverbs adverbs = listad.get(position);
        holderad.wordad.setText(adverbs.getWordad());
        holderad.meaningad.setText(adverbs.getMeaningad());
        holderad.examplead.setText(adverbs.getExamplead());
        holderad.snonymad.setText(adverbs.getSnonymad());


    }

    @Override
    public int getItemCount() {
        return listad.size();
    }

    public static class MyViewHolderad extends RecyclerView.ViewHolder{

        TextView wordad, meaningad, examplead, snonymad;

        public MyViewHolderad(@NonNull View itemView){
            super(itemView);

            wordad = itemView.findViewById(R.id.txtWordad);
            meaningad = itemView.findViewById(R.id.txtMeaningad);
            examplead = itemView.findViewById(R.id.txtExamplead);
            snonymad = itemView.findViewById(R.id.txtSnonymad);

        }
    }
}
