package com.example.newandroid;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class adverblist extends AppCompatActivity {

    RecyclerView recyclerViewad;
    DatabaseReference databasead;
    MyAdapterad myAdapterad;
    ArrayList<Adverbs> listad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adverblist);

        recyclerViewad = findViewById(R.id.adverbList);
        databasead = FirebaseDatabase.getInstance().getReference("Adverbs");
        recyclerViewad.setHasFixedSize(true);
        recyclerViewad.setLayoutManager(new LinearLayoutManager(this));

        listad = new ArrayList<>();

        myAdapterad = new MyAdapterad(this, listad);
        recyclerViewad.setAdapter(myAdapterad);

        databasead.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Adverbs adverbs = dataSnapshot.getValue(Adverbs.class);
                    listad.add(adverbs);
                }

                myAdapterad.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        })


        ;}
}