package com.example.newandroid;

public class Phrases {
    String wordom, meaningom, exampleom, snonymom;

    public String getWordom() {
        return wordom;
    }

    public String getMeaningom() {
        return meaningom;
    }

    public String getExampleom() {
        return exampleom;
    }

    public String getSnonymom() {
        return snonymom;
    }
}
