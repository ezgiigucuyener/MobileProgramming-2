package com.example.newandroid;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class adjectivelist extends AppCompatActivity {

    RecyclerView recyclerViewes;
    DatabaseReference databasees;
    MyAdapteres myAdapteres;
    ArrayList<Adjectives> listes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adjectivelist);

        recyclerViewes = findViewById(R.id.adjectiveList);
        databasees = FirebaseDatabase.getInstance().getReference("Adjectives");
        recyclerViewes.setHasFixedSize(true);
        recyclerViewes.setLayoutManager(new LinearLayoutManager(this));

        listes = new ArrayList<>();

        myAdapteres = new MyAdapteres(this, listes);
        recyclerViewes.setAdapter(myAdapteres);

        databasees.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Adjectives adjectives = dataSnapshot.getValue(Adjectives.class);
                    listes.add(adjectives);
                }

                myAdapteres.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        })


        ;}
}
