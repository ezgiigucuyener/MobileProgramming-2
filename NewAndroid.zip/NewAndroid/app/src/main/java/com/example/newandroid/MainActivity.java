package com.example.newandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button recyclerviewbtn;
    Button adverbsbtn;
    Button adjectivesbtn;
    Button phrasesbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerviewbtn = findViewById(R.id.recyclerviewbtn);
        recyclerviewbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,wordlist.class);
                startActivity(i);
                finish();
            }
        });

        adverbsbtn = findViewById(R.id.adverbsbtn);
        adverbsbtn.setOnClickListener(vi -> {
            Intent a = new Intent(MainActivity.this, adverblist.class);
            startActivity(a);
            finish();
            });

        adjectivesbtn = findViewById(R.id.adjectivesbtn);
        adjectivesbtn.setOnClickListener(ve -> {
            Intent e = new Intent(MainActivity.this, adjectivelist.class);
            startActivity(e);
            finish();
        });

        phrasesbtn = findViewById(R.id.phrasebtn);
        phrasesbtn.setOnClickListener(vo -> {
            Intent o = new Intent(MainActivity.this, phraselist.class);
            startActivity(o);
            finish();
        });

    }
}