package com.example.newandroid;

public class Adjectives {
    String wordes, meaninges, examplees, snonymes;

    public String getWordes() {
        return wordes;
    }

    public String getMeaninges() {
        return meaninges;
    }

    public String getExamplees() {
        return examplees;
    }

    public String getSnonymes() {
        return snonymes;
    }
}
