package com.example.newandroid;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterom extends RecyclerView.Adapter<MyAdapterom.MyViewHolderom>{


    Context contextom;
    ArrayList<Phrases> listom;

    public MyAdapterom(Context contextom, ArrayList<Phrases> listom) {
        this.contextom = contextom;
        this.listom = listom;
    }
    @NonNull
    public MyAdapterom.MyViewHolderom onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View vo = LayoutInflater.from(contextom).inflate(R.layout.itemom,parent,false);
        return new MyAdapterom.MyViewHolderom(vo);
    }

    public void onBindViewHolder(@NonNull MyAdapterom.MyViewHolderom holderom, int position) {
        Phrases phrases = listom.get(position);
        holderom.wordom.setText(phrases.getWordom());
        holderom.meaningom.setText(phrases.getMeaningom());
        holderom.exampleom.setText(phrases.getExampleom());
        holderom.snonymom.setText(phrases.getSnonymom());


    }

    @Override
    public int getItemCount() {
        return listom.size();
    }

    public static class MyViewHolderom extends RecyclerView.ViewHolder{

        TextView wordom, meaningom, exampleom, snonymom;

        public MyViewHolderom(@NonNull View itemView){
            super(itemView);

            wordom = itemView.findViewById(R.id.txtWordom);
            meaningom = itemView.findViewById(R.id.txtMeaningom);
            exampleom = itemView.findViewById(R.id.txtExampleom);
            snonymom = itemView.findViewById(R.id.txtSnonymom);

        }
    }

}
