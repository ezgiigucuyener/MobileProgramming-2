package com.example.newandroid;

public class Adverbs {
    String wordad, meaningad, examplead, snonymad;

    public String getWordad() {
        return wordad;
    }

    public String getMeaningad() {
        return meaningad;
    }

    public String getExamplead() {
        return examplead;
    }

    public String getSnonymad() {
        return snonymad;
    }
}
