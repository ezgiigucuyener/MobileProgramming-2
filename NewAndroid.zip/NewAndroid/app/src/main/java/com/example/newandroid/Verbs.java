package com.example.newandroid;

public class Verbs {
    String word, meaning, example, snonym;

    public String getWord() {
        return word;
    }

    public String getMeaning() {
        return meaning;
    }

    public String getExample() {
        return example;
    }

    public String getSnonym() {
        return snonym;
    }
}
